--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Debian 12.14-1.pgdg110+1)
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cadastro_motivos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cadastro_motivos (
    id bigint NOT NULL,
    tipo character varying,
    motivo character varying,
    disponibilidade boolean
);


ALTER TABLE public.cadastro_motivos OWNER TO postgres;

--
-- Name: cadastro_motivos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cadastro_motivos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cadastro_motivos_id_seq OWNER TO postgres;

--
-- Name: cadastro_motivos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cadastro_motivos_id_seq OWNED BY public.cadastro_motivos.id;


--
-- Name: ciclo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ciclo (
    id bigint NOT NULL,
    id_maquina bigint,
    id_producao bigint,
    op_producao bigint,
    id_usuario bigint,
    data timestamp without time zone
);


ALTER TABLE public.ciclo OWNER TO postgres;

--
-- Name: ciclo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ciclo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ciclo_id_seq OWNER TO postgres;

--
-- Name: ciclo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ciclo_id_seq OWNED BY public.ciclo.id;


--
-- Name: componentes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.componentes (
    id bigint NOT NULL,
    cod character varying,
    descricao character varying
);


ALTER TABLE public.componentes OWNER TO postgres;

--
-- Name: componentes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.componentes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.componentes_id_seq OWNER TO postgres;

--
-- Name: componentes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.componentes_id_seq OWNED BY public.componentes.id;


--
-- Name: maquina; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maquina (
    id bigint NOT NULL,
    nome character varying,
    fabricante character varying,
    ano character varying
);


ALTER TABLE public.maquina OWNER TO postgres;

--
-- Name: maquina_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maquina_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maquina_id_seq OWNER TO postgres;

--
-- Name: maquina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maquina_id_seq OWNED BY public.maquina.id;


--
-- Name: oee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oee (
    id bigint NOT NULL,
    op bigint,
    disponibilidade real,
    perfomance real,
    qualidade real,
    oee real,
    maquina bigint,
    dtoee timestamp(0) with time zone,
    id_producao bigint
);


ALTER TABLE public.oee OWNER TO postgres;

--
-- Name: oee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oee_id_seq OWNER TO postgres;

--
-- Name: oee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oee_id_seq OWNED BY public.oee.id;


--
-- Name: ordem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ordem (
    id bigint NOT NULL,
    ord_f character varying,
    cavi bigint,
    ativa boolean
);


ALTER TABLE public.ordem OWNER TO postgres;

--
-- Name: ordem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordem_id_seq OWNER TO postgres;

--
-- Name: ordem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordem_id_seq OWNED BY public.ordem.id;


--
-- Name: parada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parada (
    id bigint NOT NULL,
    inicio_parada timestamp without time zone,
    id_motivo bigint,
    id_usuario bigint,
    id_maquina bigint,
    id_producao bigint,
    fim_parada timestamp without time zone,
    justificativa character varying,
    estado boolean,
    tempo interval,
    dispo boolean
);


ALTER TABLE public.parada OWNER TO postgres;

--
-- Name: parada_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parada_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parada_id_seq OWNER TO postgres;

--
-- Name: parada_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parada_id_seq OWNED BY public.parada.id;


--
-- Name: parada_programada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parada_programada (
    id bigint NOT NULL,
    inicio_parada timestamp without time zone,
    id_motivo bigint,
    id_usuario bigint,
    id_maquina bigint,
    id_producao bigint,
    fim_parada timestamp without time zone,
    justificativa character varying,
    estado boolean,
    tempo interval
);


ALTER TABLE public.parada_programada OWNER TO postgres;

--
-- Name: parada_programada_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parada_programada_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parada_programada_id_seq OWNER TO postgres;

--
-- Name: parada_programada_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parada_programada_id_seq OWNED BY public.parada_programada.id;


--
-- Name: pecas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pecas (
    data_inicio timestamp without time zone,
    data_fim timestamp without time zone,
    usuario character varying,
    id bigint NOT NULL,
    id_maquina bigint
);


ALTER TABLE public.pecas OWNER TO postgres;

--
-- Name: pecas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pecas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pecas_id_seq OWNER TO postgres;

--
-- Name: pecas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pecas_id_seq OWNED BY public.pecas.id;


--
-- Name: producao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.producao (
    id bigint NOT NULL,
    id_maquina bigint,
    qtde_coletada bigint,
    dt_inicio timestamp without time zone,
    dt_fim timestamp without time zone,
    estado boolean,
    id_usuario bigint,
    liberacao boolean,
    t_padrao bigint,
    id_produto bigint,
    lote character varying,
    p_ciclo bigint,
    qtde_total bigint
);


ALTER TABLE public.producao OWNER TO postgres;

--
-- Name: producao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.producao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.producao_id_seq OWNER TO postgres;

--
-- Name: producao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.producao_id_seq OWNED BY public.producao.id;


--
-- Name: produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtos (
    id bigint NOT NULL,
    nome character varying,
    pecas_ciclo bigint,
    t_padrao bigint
);


ALTER TABLE public.produtos OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produtos_id_seq OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produtos_id_seq OWNED BY public.produtos.id;


--
-- Name: refugo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refugo (
    id bigint NOT NULL,
    data timestamp without time zone,
    quantidade bigint,
    id_motivo bigint,
    id_usuario bigint,
    id_maquina bigint,
    id_producao bigint,
    justificativa character varying,
    id_componente bigint
);


ALTER TABLE public.refugo OWNER TO postgres;

--
-- Name: refugo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.refugo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.refugo_id_seq OWNER TO postgres;

--
-- Name: refugo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.refugo_id_seq OWNED BY public.refugo.id;


--
-- Name: teste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teste (
    texto character varying,
    dt_inicio timestamp without time zone,
    botao boolean
);


ALTER TABLE public.teste OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id bigint NOT NULL,
    nome character varying,
    setor character varying,
    senha character varying,
    usuario character varying,
    privilegio bigint
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: cadastro_motivos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cadastro_motivos ALTER COLUMN id SET DEFAULT nextval('public.cadastro_motivos_id_seq'::regclass);


--
-- Name: ciclo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciclo ALTER COLUMN id SET DEFAULT nextval('public.ciclo_id_seq'::regclass);


--
-- Name: componentes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.componentes ALTER COLUMN id SET DEFAULT nextval('public.componentes_id_seq'::regclass);


--
-- Name: maquina id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquina ALTER COLUMN id SET DEFAULT nextval('public.maquina_id_seq'::regclass);


--
-- Name: oee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oee ALTER COLUMN id SET DEFAULT nextval('public.oee_id_seq'::regclass);


--
-- Name: ordem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordem ALTER COLUMN id SET DEFAULT nextval('public.ordem_id_seq'::regclass);


--
-- Name: parada id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada ALTER COLUMN id SET DEFAULT nextval('public.parada_id_seq'::regclass);


--
-- Name: parada_programada id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada ALTER COLUMN id SET DEFAULT nextval('public.parada_programada_id_seq'::regclass);


--
-- Name: pecas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pecas ALTER COLUMN id SET DEFAULT nextval('public.pecas_id_seq'::regclass);


--
-- Name: producao id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producao ALTER COLUMN id SET DEFAULT nextval('public.producao_id_seq'::regclass);


--
-- Name: produtos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos ALTER COLUMN id SET DEFAULT nextval('public.produtos_id_seq'::regclass);


--
-- Name: refugo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo ALTER COLUMN id SET DEFAULT nextval('public.refugo_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: cadastro_motivos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cadastro_motivos (id, tipo, motivo, disponibilidade) FROM stdin;
\.
COPY public.cadastro_motivos (id, tipo, motivo, disponibilidade) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: ciclo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ciclo (id, id_maquina, id_producao, op_producao, id_usuario, data) FROM stdin;
\.
COPY public.ciclo (id, id_maquina, id_producao, op_producao, id_usuario, data) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: componentes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.componentes (id, cod, descricao) FROM stdin;
\.
COPY public.componentes (id, cod, descricao) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: maquina; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maquina (id, nome, fabricante, ano) FROM stdin;
\.
COPY public.maquina (id, nome, fabricante, ano) FROM '$$PATH$$/3105.dat';

--
-- Data for Name: oee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oee (id, op, disponibilidade, perfomance, qualidade, oee, maquina, dtoee, id_producao) FROM stdin;
\.
COPY public.oee (id, op, disponibilidade, perfomance, qualidade, oee, maquina, dtoee, id_producao) FROM '$$PATH$$/3107.dat';

--
-- Data for Name: ordem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ordem (id, ord_f, cavi, ativa) FROM stdin;
\.
COPY public.ordem (id, ord_f, cavi, ativa) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: parada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parada (id, inicio_parada, id_motivo, id_usuario, id_maquina, id_producao, fim_parada, justificativa, estado, tempo, dispo) FROM stdin;
\.
COPY public.parada (id, inicio_parada, id_motivo, id_usuario, id_maquina, id_producao, fim_parada, justificativa, estado, tempo, dispo) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: parada_programada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parada_programada (id, inicio_parada, id_motivo, id_usuario, id_maquina, id_producao, fim_parada, justificativa, estado, tempo) FROM stdin;
\.
COPY public.parada_programada (id, inicio_parada, id_motivo, id_usuario, id_maquina, id_producao, fim_parada, justificativa, estado, tempo) FROM '$$PATH$$/3113.dat';

--
-- Data for Name: pecas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pecas (data_inicio, data_fim, usuario, id, id_maquina) FROM stdin;
\.
COPY public.pecas (data_inicio, data_fim, usuario, id, id_maquina) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: producao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.producao (id, id_maquina, qtde_coletada, dt_inicio, dt_fim, estado, id_usuario, liberacao, t_padrao, id_produto, lote, p_ciclo, qtde_total) FROM stdin;
\.
COPY public.producao (id, id_maquina, qtde_coletada, dt_inicio, dt_fim, estado, id_usuario, liberacao, t_padrao, id_produto, lote, p_ciclo, qtde_total) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtos (id, nome, pecas_ciclo, t_padrao) FROM stdin;
\.
COPY public.produtos (id, nome, pecas_ciclo, t_padrao) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: refugo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refugo (id, data, quantidade, id_motivo, id_usuario, id_maquina, id_producao, justificativa, id_componente) FROM stdin;
\.
COPY public.refugo (id, data, quantidade, id_motivo, id_usuario, id_maquina, id_producao, justificativa, id_componente) FROM '$$PATH$$/3121.dat';

--
-- Data for Name: teste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teste (texto, dt_inicio, botao) FROM stdin;
\.
COPY public.teste (texto, dt_inicio, botao) FROM '$$PATH$$/3123.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nome, setor, senha, usuario, privilegio) FROM stdin;
\.
COPY public.usuarios (id, nome, setor, senha, usuario, privilegio) FROM '$$PATH$$/3124.dat';

--
-- Name: cadastro_motivos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cadastro_motivos_id_seq', 13, true);


--
-- Name: ciclo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ciclo_id_seq', 97, true);


--
-- Name: componentes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.componentes_id_seq', 4, true);


--
-- Name: maquina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maquina_id_seq', 1, false);


--
-- Name: oee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oee_id_seq', 1176, true);


--
-- Name: ordem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordem_id_seq', 11, true);


--
-- Name: parada_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parada_id_seq', 168, true);


--
-- Name: parada_programada_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parada_programada_id_seq', 3, true);


--
-- Name: pecas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pecas_id_seq', 1862, true);


--
-- Name: producao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.producao_id_seq', 241, true);


--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produtos_id_seq', 2, true);


--
-- Name: refugo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.refugo_id_seq', 59, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 8, true);


--
-- Name: cadastro_motivos cadastro_motivos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cadastro_motivos
    ADD CONSTRAINT cadastro_motivos_pk PRIMARY KEY (id);


--
-- Name: ciclo ciclo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciclo
    ADD CONSTRAINT ciclo_pk PRIMARY KEY (id);


--
-- Name: componentes componentes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.componentes
    ADD CONSTRAINT componentes_pk PRIMARY KEY (id);


--
-- Name: maquina maquina_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquina
    ADD CONSTRAINT maquina_pk PRIMARY KEY (id);


--
-- Name: oee oee_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oee
    ADD CONSTRAINT oee_pk PRIMARY KEY (id);


--
-- Name: oee oee_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oee
    ADD CONSTRAINT oee_un UNIQUE (dtoee);


--
-- Name: ordem ordem_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordem
    ADD CONSTRAINT ordem_pk PRIMARY KEY (id);


--
-- Name: parada parada_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada
    ADD CONSTRAINT parada_pk PRIMARY KEY (id);


--
-- Name: parada_programada parada_programada_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada
    ADD CONSTRAINT parada_programada_pk PRIMARY KEY (id);


--
-- Name: producao producao_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producao
    ADD CONSTRAINT producao_pk PRIMARY KEY (id);


--
-- Name: produtos produtos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pk PRIMARY KEY (id);


--
-- Name: refugo refugo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_pk PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pk PRIMARY KEY (id);


--
-- Name: ciclo ciclo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciclo
    ADD CONSTRAINT ciclo_fk FOREIGN KEY (id_maquina) REFERENCES public.maquina(id);


--
-- Name: ciclo ciclo_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciclo
    ADD CONSTRAINT ciclo_fk_1 FOREIGN KEY (id_producao) REFERENCES public.producao(id);


--
-- Name: ciclo ciclo_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ciclo
    ADD CONSTRAINT ciclo_fk_2 FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: parada parada_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada
    ADD CONSTRAINT parada_fk FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: parada parada_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada
    ADD CONSTRAINT parada_fk_1 FOREIGN KEY (id_motivo) REFERENCES public.cadastro_motivos(id);


--
-- Name: parada parada_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada
    ADD CONSTRAINT parada_fk_2 FOREIGN KEY (id_maquina) REFERENCES public.maquina(id);


--
-- Name: parada parada_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada
    ADD CONSTRAINT parada_fk_3 FOREIGN KEY (id_producao) REFERENCES public.producao(id);


--
-- Name: parada_programada parada_programada_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada
    ADD CONSTRAINT parada_programada_fk FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: parada_programada parada_programada_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada
    ADD CONSTRAINT parada_programada_fk_1 FOREIGN KEY (id_motivo) REFERENCES public.cadastro_motivos(id);


--
-- Name: parada_programada parada_programada_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada
    ADD CONSTRAINT parada_programada_fk_2 FOREIGN KEY (id_maquina) REFERENCES public.maquina(id);


--
-- Name: parada_programada parada_programada_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parada_programada
    ADD CONSTRAINT parada_programada_fk_3 FOREIGN KEY (id_producao) REFERENCES public.producao(id);


--
-- Name: producao producao_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producao
    ADD CONSTRAINT producao_fk FOREIGN KEY (id_maquina) REFERENCES public.maquina(id);


--
-- Name: producao producao_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producao
    ADD CONSTRAINT producao_fk_1 FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: producao producao_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producao
    ADD CONSTRAINT producao_fk_2 FOREIGN KEY (id_produto) REFERENCES public.produtos(id);


--
-- Name: refugo refugo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_fk FOREIGN KEY (id_motivo) REFERENCES public.cadastro_motivos(id);


--
-- Name: refugo refugo_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_fk_1 FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: refugo refugo_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_fk_2 FOREIGN KEY (id_maquina) REFERENCES public.maquina(id);


--
-- Name: refugo refugo_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_fk_3 FOREIGN KEY (id_producao) REFERENCES public.producao(id);


--
-- Name: refugo refugo_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refugo
    ADD CONSTRAINT refugo_fk_4 FOREIGN KEY (id_componente) REFERENCES public.componentes(id);


--
-- PostgreSQL database dump complete
--

