--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 13.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ub_natts;
--
-- Name: ub_natts; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ub_natts WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE ub_natts OWNER TO postgres;

\connect ub_natts

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: worksessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.worksessions (
    session_id integer NOT NULL,
    operator_id integer,
    workstation_id integer,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    is_done boolean DEFAULT false,
    duration_interval interval GENERATED ALWAYS AS ((COALESCE(end_time, start_time) - start_time)) STORED,
    CONSTRAINT no_overlap_sessions CHECK ((end_time > start_time))
);


ALTER TABLE public.worksessions OWNER TO postgres;

--
-- Name: worksessions_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.worksessions_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.worksessions_session_id_seq OWNER TO postgres;

--
-- Name: worksessions_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.worksessions_session_id_seq OWNED BY public.worksessions.session_id;


--
-- Name: worksessions session_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksessions ALTER COLUMN session_id SET DEFAULT nextval('public.worksessions_session_id_seq'::regclass);


--
-- Data for Name: worksessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.worksessions (session_id, operator_id, workstation_id, start_time, end_time, is_done) FROM stdin;
\.
COPY public.worksessions (session_id, operator_id, workstation_id, start_time, end_time, is_done) FROM '$$PATH$$/3085.dat';

--
-- Name: worksessions_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.worksessions_session_id_seq', 10, true);


--
-- Name: worksessions worksessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksessions
    ADD CONSTRAINT worksessions_pkey PRIMARY KEY (session_id);


--
-- Name: idx_operator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operator_id ON public.worksessions USING btree (operator_id);


--
-- Name: idx_start_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_start_time ON public.worksessions USING btree (start_time);


--
-- Name: idx_workstation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workstation_id ON public.worksessions USING btree (workstation_id);


--
-- Name: worksessions worksessions_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksessions
    ADD CONSTRAINT worksessions_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.operators(operator_id);


--
-- Name: worksessions worksessions_workstation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.worksessions
    ADD CONSTRAINT worksessions_workstation_id_fkey FOREIGN KEY (workstation_id) REFERENCES public.workstations(workstation_id);


--
-- PostgreSQL database dump complete
--

